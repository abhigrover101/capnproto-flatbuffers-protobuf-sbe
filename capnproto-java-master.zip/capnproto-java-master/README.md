# capnproto-java: Cap'n Proto for Java

[![Build Status](https://travis-ci.org/dwrensha/capnproto-java.svg?branch=master)](https://travis-ci.org/dwrensha/capnproto-java)

[Cap'n Proto](http://capnproto.org) is an extremely efficient protocol for sharing data
and capabilities,
and capnproto-java is a work-in-progress pure Java implementation.

[Read more here.](https://dwrensha.github.io/capnproto-java/index.html)
